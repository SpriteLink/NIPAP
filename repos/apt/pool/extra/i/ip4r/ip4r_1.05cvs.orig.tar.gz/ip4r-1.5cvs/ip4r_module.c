/* $Id: ip4r_module.c,v 1.1 2011/08/22 14:06:31 andrewsn Exp $ */

#include "ipr.h"

PG_MODULE_MAGIC;

