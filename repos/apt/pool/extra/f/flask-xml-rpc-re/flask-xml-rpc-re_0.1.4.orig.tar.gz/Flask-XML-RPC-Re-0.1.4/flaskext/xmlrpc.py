import warnings

warnings.warn("flaskext.xmlrpcre namespace is deprecated, please use flask_xmlrpcre namespace instead",
              DeprecationWarning)

from flask_xmlrpcre import *
