PyNIPAP - a Python NIPAP client library
=======================================
PyNIPAP is a Python client library to communicate with the NIPAP server via
XML-RPC. It abstracts away all the evil in ze world.
