from setuptools import setup

setup(
    data_files=[
        ('share/nipap', ['nipap-www.wsgi', ]),
    ],
)
