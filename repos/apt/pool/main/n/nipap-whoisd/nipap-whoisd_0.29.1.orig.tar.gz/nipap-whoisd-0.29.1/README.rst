nipap-whoisd - the NIPAP whois daemon
=====================================
The NIPAP whois daemon provides a whois-style interface for querying data in
the NIPAP database. It receives whois queries, translates these into search
queries towards the nipapd backend and sends the result, with a whois style
format, back to the client.
